let gen_tests = ref false
let show_ast = ref false
let show_il = ref false
let ast2c = ref false
let il2c = ref false
let compile_only = ref false
let lang_file_exn = ".oat"


