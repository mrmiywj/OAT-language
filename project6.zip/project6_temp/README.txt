Add instructions that the TA can follow to grade your project. 

Your instructions should describe the steps needed to reproduce the
performance measurements you use to demonstrate the impacts of your
optimizations. 


